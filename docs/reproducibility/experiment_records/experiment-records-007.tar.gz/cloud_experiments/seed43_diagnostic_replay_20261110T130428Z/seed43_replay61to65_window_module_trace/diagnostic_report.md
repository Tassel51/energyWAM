# seed43 短重放诊断结果（2026-11-10）

## 目的与实际执行

定位 seed43 第64次更新约7478万的梯度尖峰，区分窗口、内层迭代和参数模块，并检查外层裁剪是否生效。

已按用户要求停止原 warning-only 续训：实际完成189次更新，保留完整 latest171 / best0。停止记录位于项目 logs/lab_remote_setup/seed43_stop_for_diagnostics.json。未停止其他人的任务。

本次在 compshare 主机 cpod-1x51qyjx1lqg 的物理 GPU2/3，从原 seed43 完整 step61 断点重放 update62–65，共4次真实优化器更新。北京时间21:05:02开始，21:13:29正常结束，退出码0。结束后GPU2/3均仅1MiB显存，无训练进程。源checkpoint身份未变。

保持4B模型、seed43、有效batch16、native microbatch4、K=2、Action+9Future、原外层学习率/优化器/卸载、clip=1及采样顺序。只增加被动诊断；不进行新的固定67窗口评价，不写新的大型checkpoint。配置、命令、源码、环境及恢复证据保存在本实验目录和上一级plan.json。恢复核验覆盖全部模型/优化器张量的key、shape、dtype、首尾64值，以及完整scheduler/RNG；不是全4B张量逐元素校验。随后4步的Action/Future MSE、原梯度范数、更新后两个alpha共五项均逐值精确复现原训练。CPU小模型observer等价测试也通过：最终全部模型张量逐值相同。

## 实测逐步结果

以下是变化训练batch的MSE，不是固定TRAIN/VAL评价。

| update | Action MSE | Future MSE | 原实现裁剪前总norm | 实测裁剪后总norm | 与原训练比较 |
| --- | --- | --- | --- | --- | --- |
| 62 | 1.738399 | 1.782933 | 5923011.405760 | 1.000000087 | 五项精确一致 |
| 63 | 1.381593 | 0.929032 | 12462760.531789 | 1.000000039 | 五项精确一致 |
| 64 | 0.789275 | 1.289316 | 74783008.850448 | 0.999999978 | 五项精确一致 |
| 65 | 1.091143 | 1.661892 | 2999626.919571 | 0.999999924 | 五项精确一致 |

原实现与observer按参数分组重新归约的norm有微小浮点舍入差，例如64步分别74783008.850448与74783010.086060；原实现指标与原训练精确一致。

## 窗口定位

第64步最大参数梯度来自Future方向、包含episode3346起始帧0、84、72、168的四窗口microbatch。该次反传任务模块incoming norm约7201万，语言主干约2034万，显著高于同更新的其他microbatch。

尚未计算逐窗口完整4B参数梯度，因此不能把整个尖峰唯一归因于frame84；frame84是在这一组中观察到显著内层敏感性的窗口。窗口身份由已记录的candidate seed、冻结的采样算法与固定数据清单精确还原，并校验visit position位于对应update范围；prepared batch已去掉身份字段，原始trace中的null未被改写。带身份记录另存window_inner_trace_identified.jsonl。

## 内层迭代定位

第64步Future窗口的MSE路径：

| 窗口起始帧 | 初始候选 | 第1次内层更新后 | 第2次内层更新后 |
| --- | --- | --- | --- |
| 84 | 0.094163 | 5.602920 | 4.076109 |
| 264 | 0.084723 | 40.575641 | 0.122778 |

frame84两次候选修改RMS分别2.351、3.079；frame264分别6.364、6.368。可见内层会先大幅偏离，再部分拉回。frame264虽然中间MSE最高，却不在最大反向梯度的四窗口组里，不能仅凭最终loss或最高中间loss定位梯度来源。

frame84从第2次更新后的候选向第1次更新后的候选反传时，损失梯度RMS从约1.006e-5放大到0.2363，约23487倍。第62步Future frame64该比值约173678倍。这是实际损失方向上的反向放大量，不是完整Jacobian/Hessian的谱范数测量。

## 模块定位与实际更新

第64步裁剪前参数组norm：

| 参数组 | norm | 实际参数更新norm / 更新前参数norm |
| --- | --- | --- |
| 语言主干 | 20301242 | 0.013254% |
| 任务模块 | 71974699 | 0.151873% |
| 能量头 | 28592.65 | 0.292640% |
| 可学习步长原始参数 | 302.02 | 0.070149% |

任务模块约占平方梯度总范数的92.63%。梯度最大的参数为iteration_conditioner.action_mlp.2.weight（5506万），其次action_projector.2.weight（3038万）、type_embed.weight（2188万）、action_mlp.2.bias（2142万）。这是大梯度出现的位置，不能直接断言某模块存在bug。

尽管参数名含Action，主导尖峰的反传来自Future损失：Future预测使用真实Action作为条件，梯度仍会流到Action条件网络/投影参数。不能据名称把它误判为Action损失导致。

全局clip=1确实生效，64步裁剪后总norm为0.999999978。Adam实际参数更新没有按7478万的量级直接移动；但分组更新比例小并不保证所有子模块都安全，也不保证敏感的内层映射稳定。梯度裁剪发生在内层前向/反向之后，不能消除已经发生的候选偏离和反向放大。

## 已检查的实现与数据问题

4次更新中已记录的Action/Future目标、DINO特征与mask无NaN/Inf。Action目标最大绝对值4.5234，Future目标4.9701，当前DINO特征2.7025。mask均有效。未观测到这些字段的明显量级爆炸；不等于完成原始图像、状态、全部数据集与语义正确性的审计。

对128条窗口/方向终点损失梯度，按2×方向权重×RMSE/(有效batch16×每窗口有效元素数)核对，最大相对误差1.772e-7。支持本次batch的终点MSE均值、损失权重和有效batch缩放正确；不是对整个高阶反传实现的数学证明。未执行有限差分高阶梯度检查。

## 结论、边界与下一步

本次证据支持：当前seed43异常状态下，内层迭代的候选轨迹及展开反传高度敏感；64步尖峰主要沿Future方向出现，并集中到任务条件网络/投影参数。外层clip失效、终点MSE漏除batch、已检查目标非有限值，都没有得到证据支持。

这仍不是唯一根因结论。源step61已经异常，无法定位最早从健康到异常的更新；不能证明某个窗口损坏，也不能排除更早的参数演化、归一化/条件注入或高阶导数实现问题。尚未做修复对照或重新验证seed42。

建议下一步优先对内层展开做小模型双精度有限差分核验，并针对Future步长做单变量诊断：alpha2000→1000，同时保持有效二次先验系数不变，避免同时改两项。需要更早健康checkpoint或从相同seed初始化保留早期诊断，才能追踪首次异常。上述是建议，本次没有自动追加任何训练。

## 原始证据与checkpoint

- replay_comparisons.json：4步五项逐值比较。
- restored_state_check.json、audit_status.json、replay_result.json：恢复与完成证据。
- diagnostics/window_inner_trace.jsonl、window_inner_trace_identified.jsonl、candidate_adjoint.jsonl：内层逐窗口轨迹和反向量。
- diagnostics/micro_parameter_gradients.jsonl、gradient_clipping.jsonl、parameter_updates.jsonl：逐micro参数梯度、裁剪与完整参数实际更新norm。
- diagnostics/input_statistics.jsonl、diagnostic_summary.json：输入及汇总。
- config/plan/source快照与日志保留，报告脚本另存report_provenance目录及sha256。
- 源seed43完整latest61/best0、已停续训latest171/best0保留；本诊断的final_parameter_samples.pt仅是小型参数抽样，不支持从65完整恢复。所有权重均在云盘。
