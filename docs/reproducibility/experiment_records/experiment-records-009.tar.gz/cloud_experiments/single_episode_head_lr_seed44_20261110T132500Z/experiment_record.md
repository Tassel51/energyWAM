

## 2026-11-10 21:26 CST 新seed44对照已启动（仅seed变化）

用户要求再换一个不同于42/43的seed，并明确“之前的什么checkpoint都可以删了”。选择seed44，在compshare物理GPU2/3从官方Qwen3VL4B/DINO重新初始化；不从seed43异常checkpoint续训。root `/cloud/zzc/energyWAM/experiments/single_episode_head_lr_seed44_20261110T132500Z`，arm `episode3346_headscale1_b16_micro4_seed44`，冻结源码 `/root/zzc/energyWAM/logs/frozen_sources/head_repeat_storagefix_20261110T031718Z/code`，tmux `energywam_head_lr_seed44_20261110T132500Z`。controller235788/queue235790/trainer235955已启动，当前仍加载/初始化，未把启动当作已完成更新。

YAML与seed42 storagefix、seed43 original逐结构对照，除run_id/output/notes外唯一差异trainer.seed=44；源码直接复用同冻结版本无改动。67TRAIN/16VAL固定清单相同，B16/native4/FP32/K2、A+9F、head1e-3/task1e-4/language1e-5/steps1e-3、warmup16、alphaA5/F2000、clip1、原GPU分层及卸载均不变。目标210updates/3360visits≈50.15epoch，固定评价每20update、seed2026、末端辅助2027，best按16VAL A+9F。seed同时改变任务模块初始化、训练样本次序和候选随机流。严格比较原42/43协议，沿用fixedTRAIN10x的stop，不沿用seed43后期单独授权的warn续训；已向用户明确说明停止规则。

云盘空间原72.42GiB，预算76.65GiB（3份约22.88GiB完整快照+8GiB）。本次仅删除已中断seed43 warn续训的latest171，释放约22.88GiB，68个非权重文件hash未变；warn best0、原seed43latest61/best0、seed42原胜出基线等保留。latest171现在不可恢复，记录latest171_retired_for_seed44.json；旧停止时“保留latest171”只描述当时状态。清单`checkpoint_retirement_seed44_start_20261110.json`在cloud实验根和logs/lab_remote_setup。unlink后首次free统计滞后，后续确认95.30GiB。禁止将新权重写本机盘。

CPU tiny实际云盘save1/resume2 gate通过，最终模型逐位一致，不等同真实4B恢复测试。第一次gate因冻结源码未附带tiny_cpu.yaml报FileNotFoundError，在正式训练前失败；改用当前项目fixture绝对路径后通过，两次命令与日志保留。environment_manifest已重新采集，关键包版本与原43一致，旧参考manifest另存。W&B桥已注册独立来源，曲线以真实记录为准。部署receipt logs/lab_remote_setup/head_lr_seed44_deployment.json。


2026-11-10 21:30 CST seed44启动实证：PID235955/GPU2/3完成1/210并开始第2次更新，首步86.915秒；Action MSE=0.4537394344806671、Future MSE=0.09197258204221725。CUDA allocator有分配OOM重试警告但首步完成，未当作终止性OOM。完整latest0/best0及meta已保存，实际4B新断点尚未做额外恢复试验。数据清单/标准化统计与seed43相同，54个Python归档hash完全相同，execution_options仅3项身份路径变化，初始化抽样hash按新seed变化。证据新run/startup_verification.json及seed43_control_comparison.json。确认正常开始后不继续助手持续监管。
