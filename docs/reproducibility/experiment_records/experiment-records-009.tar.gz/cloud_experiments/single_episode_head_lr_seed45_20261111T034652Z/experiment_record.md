

## 2026-11-11 11:47 CST seed44失败核查与seed45启动

用户询问seed44是否失稳，并授权尝试seed45。seed44实际完成20/210，2026-11-10 21:49:06 CST controller结束finished_with_failures；原因fixedTRAIN Future@20=1.426836533超过step0=.120372729的10倍（约11.85倍），Action从.605347700到.759320940。preclip梯度最大49065294.872565；20步最后batch A1.561512589/F3.122419596，不等同fixedTRAIN。退出-15是队列guard发TERM，不是OOM终止。仅留latest0/best0，无20步可恢复权重；failure_summary.json与logs/lab_remote_setup/head_lr_seed44_final_status.json保留证据。

按用户既有旧checkpoint清理授权及失败短试验例外，仅退休seed44 step0的latest/best两个别名和best generation，共一份22.88GiB物理快照，保留全部非权重文件并hash核对一致。seed44现在无法从checkpoint恢复；其初始化抽样/seed/source保留。manifest `/cloud/zzc/energyWAM/experiments/checkpoint_retirement_seed45_start_20261111.json`，删除后cloud空闲95.27GiB；原seed43完整61和seed42基线均未删。

seed45 root `/cloud/zzc/energyWAM/experiments/single_episode_head_lr_seed45_20261111T034652Z`，arm `episode3346_headscale1_b16_micro4_seed45`，tmux `energywam_head_lr_seed45_20261111T034652Z`，冻结code `/root/zzc/energyWAM/logs/frozen_sources/head_repeat_storagefix_20261110T031718Z/code`。compshare GPU2/3 fresh官方4B/DINO，不从失败组恢复；210updates/3360visits≈50.15epoch。与原42/43/44除seed及身份路径/notes外YAML相同，B16/native4、K2、A+9F、LR1e-5/1e-4/1e-3/1e-3、warmup16、alpha5/2000、FP32、clip1、分层与卸载不改；67TRAIN/16VAL固定清单，评价seed2026和末端2027，20update评价，原fixedTRAIN10x stop保持。seed同时控制初始化、采样和训练候选随机流。

关键包版本实测与seed44一致，环境manifest刷新；冻结数学和checkpoint代码直接复用，沿用同云盘/同冻结源码已通过的seed44 CPU tiny save1/resume2 gate，未声称本次重测或真实4B恢复新验证。空间预算latest+best+pending+8GiB=76.65GiB通过。新权重仅存云盘，best按16VAL A+9F，全状态latest/best。11:47启动，刚提交不算已完成训练更新；实际进度见queue/train_log。W&B桥自动登记独立来源。receipt logs/lab_remote_setup/head_lr_seed45_deployment.json。


## 2026-11-11 16:24 CST seed45完整结束核查：210步正常退出，拟合仍有限

本机compshare GPU2/3的episode3346_headscale1_b16_micro4_seed45已正常完成210/210（逐update global_step0–209连续核验、3360样本访问），controller/queue均complete、returncode0，结束时间2026-11-11 15:39:27 CST；train_log最后修改15:35:20 CST，之后完成末端评价/保存。查询时原训练PID589018已不存在，GPU2/3各1MiB/0%；原controller PID588844为已退出的Z（zombie）条目，不在执行训练，身份已存审计。原固定67TRAIN任一方向MSE超过初始10倍的stop规则未变，此次未触发，不是失稳保护或OOM导致停止。

固定67TRAIN evalK2：初始A0.6053476999/F0.1203727293，210步A0.4263393132/F0.1168348105，分别下降约29.57%/2.94%。固定16VAL初始A0.6641318994/F0.0901216990，210步A1.5687278602/F0.1219278334，两项均恶化；不能把正常跑完当作训练稳定或充分过拟合。固定TRAIN Future最高为40步0.4536907772（初始约3.77倍），低于10倍阈值1.2037272929；同40步VAL Future3.6338690761，但该规则按TRAIN判断。变化batch Future峰4.0252242088@48，不与固定TRAIN混淆。

仍出现巨大裁剪前梯度尖峰：update34为354726571.233105（约3.55亿），全210条param_grad_nonfinite均0；配置原有global clip1，未额外测量本run实际clip后范数，不能借用seed43短重放测量冒充本run证据。末步batch A0.5244400501/F0.1265787780，preclip10.602014；末次更新后alphaA5.0410490036/F1943.1478271484。

云盘完整latest210/best0及metadata均存在，各24568519057B；best按16VAL A+9F（K2）选择，best_history仅0步，说明后续评价无综合VAL优于初始值。只核查文件/大小/metadata，不声称新做4B恢复测试；未重启、加训、改变协议或删除权重。原始文件/root为/cloud/zzc/energyWAM/experiments/single_episode_head_lr_seed45_20261111T034652Z。本次证据logs/lab_remote_setup/head_lr_seed45_final_status.json及run/completion_audit_20261111.json，保存真实查询时间、源码证据文件hash、全固定评价时序、末步/峰值及checkpoint metadata。


## 2026-11-11 17:02 CST seed45 W&B显示不全：上传恢复已配置，等待PC代理隧道

用户截图显示seed45曲线不完整。训练原始日志仍210/210正常结束，不因网页曲线短而认定训练中止。实读run_id8973f4a3f421本地上传状态last_step190、最近记录server_ack179、saved_step178，无collector_finished；这三个数是历史本地上传记录，不是本次服务端实时查询结果。17902 TCP Connection refused；17901可连接但W&B认证请求超时；无代理直连HTTP403。服务端history本次尚未读成功，不声称最终缺失范围已确认。截图横轴0–600/纵轴上限2会压缩和截断显示，与漏传分别处理。

仅给主configs/wandb_bridge.json新增proxy_url=http://127.0.0.1:17902，账户/project/sources不变；原配置备份cloud_wandb_proxy_before_*.json。scripts/watch_wandb.py支持每配置显式覆盖四个HTTP/HTTPS代理环境变量、保留NO_PROXY，首次连通性检查前生效；无字段不改变环境。17项bridge测试通过。仅supervisorctl restart energywam-wandb，旧2678363已停止、新3724864运行，当前configured_proxy_unavailable等待网络；学校mirror/uploader、所有训练进程/配置、系统SSH/代理配置未动。用户已获PowerShell单行-R17902:127.0.0.1:7897命令并待回复。

准备scripts/verify_wandb_source.py只读独立核验：seed45每步A/F/preclip梯度630点，加固定TRAIN/VAL evalK0/K2共96点，总726点；真实本地日志210连续更新。完整/缺失/数值不匹配三种无网络fixture通过。后台tmux energywam-seed45-wandb-verify最多等待6小时（非训练监控），通过后保存logs/lab_remote_setup/seed45_wandb_verified_20261111.json；目前ProxyError，不能声称已补传或校验成功。主上传器网络恢复后按服务端ACK继续原run，不创建替代run，不重训。恢复记录seed45_wandb_proxy_recovery_20261111.json。链接https://wandb.ai/zhuzc-zhejiang-university/lte-wam/runs/8973f4a3f421。


## 2026-11-11 17:23:33 CST seed45 W&B原run补传完成：服务端726点逐项核验通过

用户恢复17902隧道后TCP/HTTP CONNECT恢复，服务器侧TLS仍间歇超时/EOF；用户PC经Clash7897对api.wandb.ai根路径收到404，证明该次PC代理TLS和HTTP正常，非API鉴权结论。独立服务端history终于确认原run8973f4a3f421为crashed、ACK179：实际缺180–210的A/F/preclip梯度93点和固定评价24点，共117点，已存在数值无冲突。证据seed45_wandb_pre_repair_20261111_last_server.json。此前“local190/历史ACK179”与本次实时服务端证明分开记录。

仅停止主energywam-wandb（PID3724864），不动训练/学校上传器。scripts/repair_wandb_source.py检查新鲜独立报告、源正式完成、同source/run、无指标冲突、主writer已退出及互斥锁，resume=must继续同run，从179后重传且重新提交固定评价；未创建替代run/更改训练数据。source主记录最后210及checkpoint210已正常保存。补传SDK一度file_stream POST和storage PUT遭EOF、持续重试，无明确HTTP4xx/5xx或fatal。期间曾请用户换代理节点，但随后自动重试成功，已明确告知无需再切换，不能将成功归因未获确认的节点切换。

最终服务端state=finished、last_uploaded_update210、source_training_completed=true。独立对照210更新A/F/梯度共630点和固定67TRAIN/16VAL evalK0/K2共96点，总726点；缺失0、数值不匹配0（容差1e-8*max(1,abs(value)))。最终证据seed45_wandb_verified_20261111.json；SDK receipt seed45_wandb_isolated_repair_20261111.json仅标提交完成，由独立核验提供完整性证据。verify脚本现在额外保存last_server回执，防后续网络失败覆盖最近真实ACK。

repair/helper+原bridge共29项无网络测试通过。restore_wandb_after_repair.py在确认隔离worker退出后仅恢复主service，returncode0；当前主PID3961028运行、新代理17902，自动核验/补传任务已完成。restore receipt为seed45_wandb_isolated_repair_20261111_uploader_restored.json。训练没有重启，权重未改。链接https://wandb.ai/zhuzc-zhejiang-university/lte-wam/runs/8973f4a3f421。网页若仍截断，可刷新并调整横轴0–210、纵轴自动；坐标范围是显示问题，与本次已解决的数据漏传分别说明。
