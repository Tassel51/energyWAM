"""EnergyWAM subpackage."""
