#!/usr/bin/env python
"""One model over an explicitly selected GPU pair; shared BI optimizer step."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'scripts'))

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--steps',type=int,required=True)
    p.add_argument('--resume');p.add_argument('--fixed-window-manifest',required=True);p.add_argument('--probe-eval-interval',type=int,default=20)
    p.add_argument('--physical-gpus',default='2,3',choices=['2,3','0,1'],help='Explicit authorized physical GPU pair')
    p.add_argument('--profile',action='store_true',help='Skip evaluation/checkpoint writes for bounded throughput probes')
    p.add_argument('--evaluate-only',action='store_true',help='Read-only fixed-window evaluation, no checkpoint rewrite')
    args=p.parse_args()
    if os.environ.get('CUDA_VISIBLE_DEVICES')!=args.physical_gpus:raise RuntimeError('visible GPUs must match explicitly selected physical pair')
    physical_gpus=[int(x) for x in args.physical_gpus.split(',')]
    import torch
    from torch.utils.data import DataLoader
    from energywam.config import load_config
    from energywam.models.energy_wam import QwenEnergyWAM
    from energywam.training.shared_microbatch import SharedMicrobatchTrainer
    from energywam.training.run_state import FixedSampleBudgetSampler,save_latest
    from energywam.data.energy_dataset import collate_energy_batch
    from k_training_probe import fixed_dataset,evaluate,dataset_baselines
    import train as T
    cfg=load_config(args.config)
    if cfg.trainer.language_model_devices!=[0,1]:raise RuntimeError('expected two-card layer placement')
    cfg.trainer.max_train_steps=args.steps
    output=Path(cfg.trainer.output_dir);output.mkdir(parents=True,exist_ok=True)
    if not args.resume:
        import zipfile
        with zipfile.ZipFile(output/'source_initial.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
            files=list((ROOT/'energywam').rglob('*.py'))
            files += [ROOT/'scripts'/name for name in ['train_shared_sharded.py','k_training_probe.py','train.py']]
            for source in files:archive.write(source,str(source.relative_to(ROOT)))
            archive.write(args.config,'experiment_config.yaml')
            archive.write(args.fixed_window_manifest,'sample_manifest.json')
    torch.manual_seed(cfg.trainer.seed)
    bundle=T.resolve_training_stats(cfg,checkpoint_path=args.resume)
    model=QwenEnergyWAM(cfg,stats_bundle=bundle)
    trainer=SharedMicrobatchTrainer(cfg,model)
    if args.resume:trainer.load(args.resume)
    trainer.export_config()
    digest=hashlib.sha256();placement={}
    for name,parameter in model.named_parameters():
        digest.update(name.encode());digest.update(parameter.detach().reshape(-1)[:64].float().cpu().numpy().tobytes())
        placement[str(parameter.device)]=placement.get(str(parameter.device),0)+parameter.numel()
    if set(placement)!={'cuda:0','cuda:1'}:raise RuntimeError('model not distributed over exactly two visible GPUs')
    (output/f'initialization_step{trainer.global_step}.json').write_text(json.dumps({'sampled_parameter_sha256':digest.hexdigest(),
        'sample_per_parameter':64,'full_parameter_hash':False,'global_step':trainer.global_step,'stats_fingerprint':bundle.fingerprint,
        'model_instances':1,'parameter_numel_by_device':placement,'physical_gpus':physical_gpus},indent=2))
    manifest=json.loads(Path(args.fixed_window_manifest).read_text())
    train_ids={w['episode_index'] for w in manifest['windows'] if w['split']=='train'}
    val_ids={w['episode_index'] for w in manifest['windows'] if w['split']=='val'}
    if not train_ids.isdisjoint(val_ids):raise ValueError('train/val episode leakage')
    dataset,_=fixed_dataset(cfg,model,manifest,'train')
    sampler=FixedSampleBudgetSampler(len(dataset),cfg.trainer.seed,consumed=trainer.global_step*cfg.trainer.per_device_batch_size,total=max(args.steps,trainer.global_step)*cfg.trainer.per_device_batch_size)
    loader=DataLoader(dataset,batch_size=cfg.trainer.per_device_batch_size,sampler=sampler,drop_last=True,num_workers=0,
        generator=torch.Generator().manual_seed(cfg.trainer.seed),collate_fn=collate_energy_batch)
    iterator=iter(loader)
    def assess():
        for rank,direction in enumerate(['action','future']):
            if not (output/f'eval_{trainer.global_step:04d}_{direction}.json').exists():
                evaluate(trainer,args.fixed_window_manifest,output,rank)
    if not args.profile and os.environ.get('ENERGYWAM_FIXED_DATA_CACHE')=='1':
        dataset_baselines(cfg,model,args.fixed_window_manifest,output)
    if not args.profile:assess()
    if args.evaluate_only:return
    records=json.loads((output/'speed_report.json').read_text())['steps'] if args.resume and (output/'speed_report.json').exists() else []
    last_saved=None
    while trainer.global_step<args.steps:
        begin=time.monotonic()
        try:batch=next(iterator)
        except StopIteration:iterator=iter(loader);batch=next(iterator)
        data=time.monotonic()-begin
        print(f'[shared-sharded] begin update={trainer.global_step}',flush=True)
        row=trainer.train_step(batch)
        for dev in range(2):torch.cuda.synchronize(dev)
        elapsed=time.monotonic()-begin
        row.update(end_to_end_seconds=elapsed,data_seconds=data,end_to_end_samples_per_second=cfg.trainer.per_device_batch_size/elapsed,global_step_completed=trainer.global_step)
        for dev in range(2):row[f'gpu{dev}_peak_allocated_gib']=torch.cuda.max_memory_allocated(dev)/2**30
        row['trim_between_directions']=int(os.environ.get('ENERGYWAM_TRIM_BETWEEN_DIRECTIONS','1')=='1')
        row['sample_aligned_rng']=int(os.environ.get('ENERGYWAM_SAMPLE_ALIGNED_RNG','0')=='1')
        with (output/'timing_history.jsonl').open('a') as timing_stream:timing_stream.write(json.dumps(row)+'\n')
        records.append(row);records=records[-100:]
        (output/'speed_report.json').write_text(json.dumps({'mode':'one_model_layer_sharded','model_instances':1,'physical_gpus':physical_gpus,
            'global_batch':cfg.trainer.per_device_batch_size,'completed_steps':trainer.global_step,'steps':records},indent=2))
        print(f'[shared-sharded] completed={trainer.global_step} seconds={elapsed:.3f}',flush=True)
        if not args.profile and (trainer.global_step%cfg.trainer.save_interval==0 or trainer.global_step==args.steps):
            save_latest(trainer,output);last_saved=trainer.global_step
        if not args.profile and (trainer.global_step%args.probe_eval_interval==0 or trainer.global_step==args.steps):assess()
    if not args.profile and last_saved!=trainer.global_step:save_latest(trainer,output)
    if args.profile:
        torch.save({n:p.detach().reshape(-1)[:64].float().cpu().clone() for n,p in model.named_parameters()},output/'final_parameter_samples.pt')
    (output/'final_report.json').write_text(json.dumps({'global_step':trainer.global_step,'model_instances':1,'global_batch':cfg.trainer.per_device_batch_size,'last_loss':records[-1] if records else None},indent=2))

if __name__=='__main__':main()
