"""Bounded checkpoint storage and deterministic, seekable training order."""
import os
from pathlib import Path
import torch
from torch.utils.data import Sampler


class ResumableWindowSampler(Sampler):
    def __init__(self, size, seed, consumed=0, shuffle=True, batch_size=2):
        self.size, self.seed, self.consumed = size, seed, consumed
        self.shuffle = shuffle
        self.usable = size // batch_size * batch_size
        if not self.usable:
            raise ValueError('dataset has fewer than one batch')

    def __iter__(self):
        epoch, offset = divmod(self.consumed, self.usable)
        order = torch.randperm(self.size, generator=torch.Generator().manual_seed(self.seed + epoch)) if self.shuffle else torch.arange(self.size)
        for i in range(offset, self.usable):
            yield int(order[i])
        self.consumed = (epoch + 1) * self.usable

    def __len__(self):
        return self.usable - self.consumed % self.usable


def save_latest(trainer, output):
    """Serialize this project's large rolling writes; only one pending copy."""
    import fcntl
    lock_path = Path(__file__).resolve().parents[2]/'logs'/'.checkpoint_write.lock'
    lock_path.parent.mkdir(parents=True,exist_ok=True)
    with lock_path.open('a+b') as lock:
        fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        return _save_latest_locked(trainer,output)


def _save_latest_locked(trainer, output):
    """Keep old checkpoint until the replacement has been saved and fsynced."""
    output = Path(output)
    try:
        temporary = trainer.save('ckpt_pending.pt')
    except Exception:
        # A failed serialization is never a recoverable checkpoint. Keep the
        # previous latest intact and release partial disk usage before retry.
        (output / 'ckpt_pending.pt').unlink(missing_ok=True)
        (output / 'ckpt_pending.pt.meta.json').unlink(missing_ok=True)
        raise
    with temporary.open('rb') as stream:
        os.fsync(stream.fileno())
    latest = output / 'ckpt_latest.pt'
    os.replace(temporary, latest)
    meta = Path(str(temporary) + '.meta.json')
    if meta.exists():
        os.replace(meta, Path(str(latest) + '.meta.json'))
    fd = os.open(output, os.O_DIRECTORY)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)
    return latest


class FixedSampleBudgetSampler(Sampler):
    """Batch-independent order; batches may cross permutation boundaries.

    Unlike epoch drop_last sampling, batch8 cannot silently skip the final
    four windows of a 20-window pool. Positions are the shared experiment axis.
    """
    def __init__(self,size,seed,consumed,total):
        if size<1 or consumed<0 or total<consumed:
            raise ValueError('invalid sample budget')
        self.size,self.seed,self.consumed,self.total=size,seed,consumed,total

    def __iter__(self):
        cached_epoch=None;order=None
        for position in range(self.consumed,self.total):
            epoch,offset=divmod(position,self.size)
            if epoch!=cached_epoch:
                order=torch.randperm(self.size,generator=torch.Generator().manual_seed(self.seed+epoch)).tolist()
                cached_epoch=epoch
            yield order[offset]

    def __len__(self):return self.total-self.consumed
