"""Preserve one complete best snapshot independently of rolling latest.

The checkpoint, sidecar and selection metadata live in one immutable generation.
Atomic pointer replacement commits a generation; hard links avoid copying full
states when best is also latest. The payload remains an ordinary full checkpoint.
"""
import datetime
import fcntl
import json
import math
import os
import shutil
import uuid
from pathlib import Path


def _sync_dir(path):
    fd=os.open(path,os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)


def _pointer(path,target):
    pending=path.with_name(path.name+'.link_pending')
    pending.unlink(missing_ok=True)
    pending.symlink_to(target)
    os.replace(pending,path)


def promote_latest_to_best(output,*,global_step,score,metrics,criterion):
    """Minimize a predeclared finite validation score; never modify latest."""
    output=Path(output)
    score=float(score)
    if not math.isfinite(score):raise ValueError('best score must be finite')
    if not criterion or not metrics:raise ValueError('explicit validation criterion and component metrics required')
    if any(not math.isfinite(float(v)) for v in metrics.values()):raise ValueError('best component metric must be finite')
    lock=Path(__file__).resolve().parents[2]/'logs/.checkpoint_write.lock'
    lock.parent.mkdir(parents=True,exist_ok=True)
    with lock.open('a+b') as stream:
        fcntl.flock(stream.fileno(),fcntl.LOCK_EX)
        selection=output/'best_selection.json'
        old=json.loads(selection.read_text()) if selection.exists() else None
        if old and old['criterion']!=criterion:raise ValueError('best validation criterion cannot change within a run')
        if old and score>=old['score']:return False
        latest=output/'ckpt_latest.pt';meta=Path(str(latest)+'.meta.json')
        if not latest.exists() or not meta.exists():raise ValueError('complete latest checkpoint and metadata required')
        saved=json.loads(meta.read_text())
        if saved['meta']['global_step']!=global_step:raise ValueError('latest does not represent evaluated weights')
        store=output/'.best_snapshots';store.mkdir(exist_ok=True)
        generation=store/f'step{global_step:08d}_{uuid.uuid4().hex}'
        generation.mkdir();committed=False
        try:
            for source,name in [(latest,'checkpoint.pt'),(meta,'checkpoint.pt.meta.json')]:
                dest=generation/name
                try:os.link(source,dest)
                except OSError:shutil.copyfile(source,dest)
                with dest.open('rb') as f:os.fsync(f.fileno())
            info=dict(global_step=int(global_step),score=score,metrics={k:float(v) for k,v in metrics.items()},criterion=criterion,selected_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
            (generation/'selection.json').write_text(json.dumps(info,indent=2))
            with (generation/'selection.json').open('rb') as f:os.fsync(f.fileno())
            _sync_dir(generation);_sync_dir(store)
            # Public aliases resolve through one atomic generation pointer.
            for alias,target in [('ckpt_best.pt','.best_current/checkpoint.pt'),('ckpt_best.pt.meta.json','.best_current/checkpoint.pt.meta.json'),('best_selection.json','.best_current/selection.json')]:
                path=output/alias
                if path.exists() and not path.is_symlink():raise ValueError(f'legacy best file requires explicit migration: {path}')
                if not path.is_symlink():_pointer(path,target)
            _pointer(output/'.best_current',str(generation.relative_to(output)))
            committed=True;_sync_dir(output)
            with (output/'best_history.jsonl').open('a') as f:f.write(json.dumps(info)+'\n')
            for previous in store.iterdir():
                if previous!=generation and previous.is_dir() and not previous.is_symlink():shutil.rmtree(previous)
            _sync_dir(store)
            return True
        finally:
            if not committed:shutil.rmtree(generation,ignore_errors=True)
